⚠️ Purpose:  
This is just a test file to simulate the process of uploading,  
analyzing, and viewing results.

🔬 Notes:  
- It has no biological significance.  
- The analysis will take approximately 30 minutes.

✅ Steps:  
1. Fill in the contents below in the form step by step 
2. Upload those files:
	a. genome file: example.fa.gz 
	b. annotation file: example.gff3.gz
	c. species image: example.png
3. Click "Submit"
4. Click "Copy all URLs"
5. Check the task status by "Status URL"
6. Click "Open Massage" to see the process of analyzing
7. Wait for analysis to complete (~30 mins)
8. View the results by "Result URL"

==Example form===================================================
Latin Name: Oryza sativa
Cultivar Name: NIP
Haploid Type: Haploid1
Common Name: Rice
Ploidy: Diploid(2x)
Chromosome Number: 1
BUSCO: 98.1
QV: 58.3
LAI: 25.2
Email: example@gmail.com
Author: Tom
Unit: Plant Center
DOI: https://doi.org/
Message: This is a test genome and has no biological significance.
Genome Sequencing: Illumina + HiFi + ONT + Hi-C
Genome Survey: Jellyfish v2.3.1 + GenomeScope v2.0
Genome Assembly by HiFi: Hifiasm-0.24.0-r702
Genome Assembly by ONT: NextDenovo v2.5.0 + Canu v1.5
Organelle Genomes Assembly: Getorganelle v1.7.6
Genome Polish: Pilon v1.24 + Nextpolish v1.2.4
Hi-C Scaffolding: Juicer v1.5 + 3D-DNA + Juicebox v1.11.08
Gap Filling: TGS-GapCloser + LR_Gapcloser
Telomere Identification: Screening CCCTAAA by TRF v4.09
Centromere Identification: Screening CENH3 repeat
Polyploid Subgenome Phasing: SubPhaser v1.2
Repeat Annotation: LTR_FINDER v1.1 + RepeatModeler v2.0.1 + EDTA v1.9.3 + RepeatMasker v4.0.9
Gene Model Prediction: AUGUSTUS v3.2.3 + MAKER v2.31.9 + Trinity v2.13.2 + CD-HIT v4.6
==Example form===================================================
